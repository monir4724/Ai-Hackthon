---
name: Vigilant Guardian Dark
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d6c4b0'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#9e8e7c'
  outline-variant: '#514536'
  surface-tint: '#ffb956'
  primary: '#ffc16c'
  on-primary: '#462b00'
  primary-container: '#e8a33d'
  on-primary-container: '#5f3c00'
  inverse-primary: '#835400'
  secondary: '#b7c6ee'
  on-secondary: '#213050'
  secondary-container: '#384668'
  on-secondary-container: '#a6b5dc'
  tertiary: '#cacdca'
  on-tertiary: '#2e312f'
  tertiary-container: '#afb1af'
  on-tertiary-container: '#414442'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb5'
  primary-fixed-dim: '#ffb956'
  on-primary-fixed: '#2a1800'
  on-primary-fixed-variant: '#643f00'
  secondary-fixed: '#d9e2ff'
  secondary-fixed-dim: '#b7c6ee'
  on-secondary-fixed: '#0a1a3a'
  on-secondary-fixed-variant: '#384668'
  tertiary-fixed: '#e1e3e0'
  tertiary-fixed-dim: '#c5c7c4'
  on-tertiary-fixed: '#191c1b'
  on-tertiary-fixed-variant: '#444746'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  title-md:
    fontFamily: Tiro Bangla
    fontSize: 22px
    fontWeight: '400'
    lineHeight: 28px
  body-lg:
    fontFamily: Hind Siliguri
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hind Siliguri
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-mono:
    fontFamily: IBM Plex Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
  stamp-lg:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '900'
    lineHeight: 24px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  max-width: 1440px
---

## Brand & Style
The design system emphasizes authority, resilience, and clandestine oversight. Designed for high-stakes security monitoring and archival documentation, the aesthetic pivots to a "Tactical Command" style. It blends the gravitas of traditional editorial design with the high-performance utility of a modern operations center.

The dark mode adaptation transforms the brand from a parchment-like official document into a luminous digital dashboard. It retains the signature "ink-stamp" motif—using subtle rotation and slight opacity variations—to signify verification and status. The atmosphere is quiet, focused, and impenetrable, evoking the feeling of a secure bunker or a private intelligence briefing.

## Colors
The palette is rooted in deep midnight tones to minimize eye strain during extended surveillance sessions.

- **Surface & Background**: The primary canvas is `#121212`, providing a near-black foundation that recedes entirely.
- **Surface Container**: The brand Indigo (`#1B2A4A`) is repurposed as the secondary layer, creating depth for cards, sidebars, and navigational elements.
- **Primary Accent**: Marigold Amber (`#E8A33D`) is used sparingly for critical actions, active states, and high-priority indicators. 
- **Typography (Ink)**: Sage-white (`#EFF1EE`) serves as the primary text color, providing high legibility against the dark void without the harshness of pure white.
- **Functional Colors**: Danger and Success colors are slightly desaturated and brightened from their original values to ensure they "glow" safely against dark surfaces without vibrating.

## Typography
The typographic system maintains a tension between classical authority and technical precision.

- **Serifs (Playfair Display & Tiro Bangla)**: Used for high-level headings and significant statements. These should always appear in Sage-white to maintain a "printed" look on the digital screen.
- **Sans-Serif (Hind Siliguri)**: The workhorse for all body copy and descriptions. Its clean, open apertures ensure readability even on low-quality displays.
- **Monospace (IBM Plex Mono)**: Reserved for metadata, timestamps, and system status. It reinforces the archival and technical nature of this design system.
- **Stamp Style**: For specific status indicators (e.g., "APPROVED", "SECURED"), use Playfair Display in all caps with a 3-degree counter-clockwise rotation and a subtle border.

## Layout & Spacing
This design system utilizes a structured 12-column grid for desktop and a 4-column grid for mobile. 

The layout philosophy is "Information Density with Intent." Use generous outer margins (`64px` on desktop) to frame the content like a formal document, but maintain tight, efficient spacing (`8px` increments) within functional components to reflect a data-driven environment.

All significant containers should be aligned to the grid, but the "Ink-Stamp" badges are permitted to break the grid slightly with their 3-degree rotation to create a sense of human verification over a rigid machine-made layout.

## Elevation & Depth
In this dark environment, depth is achieved through **Tonal Layering** rather than traditional shadows.

1.  **Level 0 (Background)**: `#121212` – The base floor.
2.  **Level 1 (Containers)**: `#1B2A4A` – Used for primary content areas. These have a subtle `1px` border of `rgba(239, 241, 238, 0.1)` to define edges.
3.  **Level 2 (Popovers/Modals)**: A slightly lighter variation of the Indigo or a semi-transparent blur (`backdrop-filter: blur(12px)`) to indicate temporary overlays.

Shadows, if used, should be sharp and high-offset (e.g., `4px 4px 0px`) in a solid dark tone to mimic "hard ink" rather than soft light, reinforcing the brutalist, authoritative feel.

## Shapes
The shape language is disciplined and geometric. 

- **Corners**: A consistent `4px` to `6px` radius is applied to all buttons, cards, and input fields. This "softened square" approach maintains a serious, institutional feel while avoiding the aggressive sharpness of pure 0px corners.
- **The Stamp**: Status badges must be rectangular with a `2px` solid border, containing centered uppercase text. The 3-degree rotation is the defining characteristic of this system's shape language.
- **Separators**: Use thin, low-opacity lines to divide content sections, mimicking the ruled lines of a ledger.

## Components
- **Buttons**:
    - **Primary**: Marigold Amber background with `#121212` text. Bold, no-nonsense.
    - **Secondary**: Transparent background with a `2px` Sage-white border.
- **Ink-Stamp Badges**: These are the primary status indicators. They should be semi-transparent when "Draft" and fully opaque when "Verified." Always apply the signature rotation.
- **Input Fields**: Dark backgrounds (`#121212`) with a Sage-white bottom-border only. This mimics the "fill in the blanks" style of paper forms.
- **Cards**: Use the Indigo Surface Container (`#1B2A4A`). Headers within cards should use the Monospace label font to indicate technical data.
- **Lists**: Strictly ruled with `1px` borders. Use IBM Plex Mono for index numbers (e.g., 01, 02, 03) to emphasize the sequential, archival nature of the data.